small piece of code for Iron Function(Hot function)
